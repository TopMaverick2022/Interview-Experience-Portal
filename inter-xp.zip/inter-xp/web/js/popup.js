/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */
 

 const images = [
                    'imgs/accenture.webp',
                    'imgs/Google.jpg',
                    'imgs/Zoho.jpg',
                    'imgs/cognizant.jpg',
                    'imgs/ibm.jpg',
                    'imgs/infosys.avif',
                    'imgs/microsoft.jpg',
                    'imgs/tcs.avif',
                    'imgs/wipro.jpg',
                    'imgs/capgemini.avif',
                    'imgs/hcltech.avif',
                    'imgs/deloitte.webp'
                ];